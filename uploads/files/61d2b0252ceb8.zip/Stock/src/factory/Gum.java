package factory;

public class Gum implements Ifactory {
	@Override
	public void contain() {
		System.out.println();
		System.out.println("Gum Flavors");
		System.out.println("**************************************");
		System.out.println("1- Ment Biscuits");
		System.out.println("2- strawberry Biscuits");
		
	}
}
