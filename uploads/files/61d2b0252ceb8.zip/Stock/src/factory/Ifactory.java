package factory;

public interface Ifactory {
	void contain();
}
