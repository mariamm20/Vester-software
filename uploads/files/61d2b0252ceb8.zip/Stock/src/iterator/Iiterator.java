package iterator;

public interface Iiterator {
	boolean hasNext();
	Object next();
}
