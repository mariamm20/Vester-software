package iterator;

public interface Istockiterate {
	Iiterator getproducts();
}
