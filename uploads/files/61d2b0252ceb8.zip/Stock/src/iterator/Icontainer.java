package iterator;

public interface Icontainer {
	Iiterator getIterator();
}
