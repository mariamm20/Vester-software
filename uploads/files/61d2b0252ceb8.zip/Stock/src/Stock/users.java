
package Stock;

import facade.GetUserName;
import facade.facade;
import factory.Ifactory;
import factory.factory;
import proxy.proxy;

public class users {
	public static void main(String[] args) {
		facade run = new facade();
		run.run();
		proxy p = new proxy(GetUserName.userName,GetUserName.password);
		p.display();
		factory f = new factory();
		Ifactory x = f.getcategory();
		x.contain();
	}
}
