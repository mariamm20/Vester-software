package facade;

public interface EnterUser {
	void printMessage();
}