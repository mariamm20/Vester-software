package proxy;

public interface Iauthorize {
	void display();
}
