﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using static System.Data.SqlClient.SqlException;

namespace WindowsFormsApplication3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            




            if (textBox1.Text== "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "")
            {
                MessageBox.Show("Please fill all fields", "warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }

            else if (textBox5.Text != textBox6.Text)
            {
                MessageBox.Show("please make sure that password and Confirm password are the same", "Warning");
            }

            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-474UL3G\SQLEXPRESS;Initial Catalog=orderPizza;Integrated Security=True");
                SqlCommand cmd = new SqlCommand(@"USE [orderPizza]
                            

                            INSERT INTO[dbo].[UserSignUp]
                                       ([Fname]
                                       ,[Lname]
                                       ,[Email]
                                       ,[Phone]
                                        ,[Password]
                                         )
                                 VALUES
                                       ( '" + textBox1.Text + "','" + textBox2.Text + "', '" + textBox3.Text + "','" + textBox4.Text + "', '" + textBox5.Text + "')", con);


                con.Open();
                cmd.ExecuteNonQuery();

                con.Close();
                
                Form3 f3 = new Form3();
                f3.Show();
                this.Hide();

                MessageBox.Show("register Successfully");

            }



            

        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
