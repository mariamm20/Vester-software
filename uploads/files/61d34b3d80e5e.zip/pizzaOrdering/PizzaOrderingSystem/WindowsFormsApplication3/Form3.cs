﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace WindowsFormsApplication3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Email or Password is empty, please fill it" , "Warning");
            }
            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-474UL3G\SQLEXPRESS;Initial Catalog=orderPizza;Integrated Security=True");
                con.Open();
                SqlCommand check_Email= new SqlCommand("SELECT COUNT(*) FROM [orderPizza].[dbo].[UserSignUp] WHERE ([Email] = @Email)", con);
                check_Email.Parameters.AddWithValue("@Email", textBox1.Text);
                int UserExist = (int)check_Email.ExecuteScalar();

                if (UserExist > 0)
                {
                    //SqlCommand md = new SqlCommand(@"USE [pizzaRestaurant]
                            

                    //        INSERT INTO[dbo].[Login]
                                       
                    //                   ([Email]
                    //                   ,[Password])
                    //             VALUES
                    //                   ( '" + textBox1.Text + "','" + textBox2.Text + "')", con);


                   // con.Open();
                    //md.ExecuteNonQuery();

                    con.Close();

                    Form1 f1 = new Form1();
                    f1.Show();
                    this.Hide();

                }
                else
                {
                    MessageBox.Show("error");
                }

            }

            

        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
